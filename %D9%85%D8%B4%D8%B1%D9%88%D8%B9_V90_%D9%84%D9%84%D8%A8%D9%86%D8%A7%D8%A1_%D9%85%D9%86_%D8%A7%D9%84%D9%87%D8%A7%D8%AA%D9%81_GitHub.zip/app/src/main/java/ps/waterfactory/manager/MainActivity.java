package ps.waterfactory.manager;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int PICK_JSON=12, SAVE_JSON=13;
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private String pendingJson;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false); s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new BackupBridge(),"AndroidBackup");
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
                Uri uri=request.getUrl();
                if("appassets.androidplatform.net".equals(uri.getHost()) && "/index.html".equals(uri.getPath())){
                    try {return new WebResourceResponse("text/html","UTF-8",getAssets().open("index.html"));}
                    catch(Exception ignored){}
                }
                return new WebResourceResponse("text/plain","UTF-8",new java.io.ByteArrayInputStream(new byte[0]));
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(chooser!=null)chooser.onReceiveValue(null);
                chooser=callback;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/json");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"});
                try{startActivityForResult(i,PICK_JSON);}catch(ActivityNotFoundException e){chooser.onReceiveValue(null);chooser=null;toast("لا يوجد تطبيق لاختيار الملفات");}
                return true;
            }
        });
        web.loadUrl("https://appassets.androidplatform.net/index.html");
    }
    public class BackupBridge {
        @JavascriptInterface public void saveJson(String name,String json){
            if(json==null||json.length()>25_000_000){runOnUiThread(()->toast("النسخة أكبر من الحد المسموح"));return;}
            runOnUiThread(()->{
                pendingJson=json;
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, name);
                try{startActivityForResult(i,SAVE_JSON);}catch(Exception e){pendingJson=null;toast("تعذر فتح نافذة الحفظ");}
            });
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==PICK_JSON){if(chooser!=null){chooser.onReceiveValue(result==RESULT_OK&&data!=null?new Uri[]{data.getData()}:null);chooser=null;}return;}
        if(request==SAVE_JSON){
            if(result==RESULT_OK&&data!=null&&pendingJson!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out==null)throw new Exception("no stream");
                    out.write(pendingJson.getBytes(StandardCharsets.UTF_8));out.flush();
                    toast("تم حفظ ملف النسخة الاحتياطية");
                }catch(Exception e){toast("فشل حفظ النسخة: "+e.getMessage());}
            }else toast("أُلغي حفظ النسخة");
            pendingJson=null;
        }
    }
    private void toast(String t){Toast.makeText(this,t,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
